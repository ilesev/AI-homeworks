package tictactoe;

public class Main {
    public static void main(String[] args) {
        // if you want the AI to be first initialize the game like: "TicTacToe game = new TicTacToe(Player.COMPUTER);"
        TicTacToe game = new TicTacToe();
        game.play();
    }
}
